# A Tiny Game For You 🎁

## Fastest free deployment: GitHub Pages

1. Create/sign in to a GitHub account.
2. Create a **new public repository**, for example `tiny-heart-game`.
3. Upload `index.html` to the repository root.
4. Open **Settings → Pages**.
5. Under **Build and deployment**, choose **Deploy from a branch**.
6. Choose branch `main` and folder `/ (root)`, then save.
7. Wait for GitHub Pages to finish deploying.
8. Your HTTPS URL will normally be:
   `https://YOUR-USERNAME.github.io/tiny-heart-game/`
9. Open that URL on a phone first and test the game.
10. Send the final URL to ChatGPT and ask: **“Generate the QR code for this exact URL.”**

No server, database, login, external JavaScript library, or paid hosting is required.
